#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
# 
#    http://shiny.rstudio.com/
#    https://rstudio.github.io/shinydashboard/get_started.html


install.packages("shinydashboard")
library(shiny)
library(shinydashboard)

#Edit the sidebar
sidebar <- dashboardSidebar(
  sidebarMenu(
    menuItem("Intro", tabName = "Intro", icon = icon("Intro"))
    , menuItem("Set", tabName = "Set", icon = icon("Set"))
    , menuItem("Dashboard", tabName = "Dash",icon = icon("Dash"))
    , menuItem("About Ticker", tabName = "AboutTK", icon = icon("Ticker"))
    , menuItem("About Efficient Frontier", tabName = "AboutEF", icon = icon("AboutEF"))
    , menuItem("About Harry Markovitz", tabName = "AboutHM", icon = icon("AboutHM"))
    , menuItem("Contacts", icon= icon("file-code-o"),href = "https://github.com/JeyDi/RShinyEfficientFrontier")
    
  )
)

#Edit the main header of the dashboard
header <- dashboardHeader(title = "Efficient Frontier")

#Edit the body of the dashboard
body <- dashboardBody(# Boxes need to be put in a row (or column)
  tabItems(
    tabItem(tabName = "Intro",
            h1("Intro")),
    tabItem(tabName = "Set",
            fluidRow(
            dateRangeInput("dates", h3("Date Range")),
            sliderInput("SliderTicker", "Number of Ticker:", min = 1, max = 5, value = 1)
                    )
           ),
    tabItem(tabName = "Dash",
  fluidRow(
    box(plotOutput("plot1", height = 250)),
    box(
      title = "Controls",
      sliderInput("sliderEsempio", "Number of observations:", 1, 100, 50)
    )
   )
  ),
  tabItem(tabName = "AboutEF"),
  tabItem(tabName = "AboutHM")
 )
)

#Function for rendering the page
dashboardPage(
  skin = "blue",
  header,
  sidebar,
  body

)